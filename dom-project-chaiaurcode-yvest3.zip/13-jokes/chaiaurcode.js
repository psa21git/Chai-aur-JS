const url = 'https://api.chucknorris.io/jokes/random';

// handle this end point with XMLHttpRequest

// handle this end point with promises

// handle the case of race condition
